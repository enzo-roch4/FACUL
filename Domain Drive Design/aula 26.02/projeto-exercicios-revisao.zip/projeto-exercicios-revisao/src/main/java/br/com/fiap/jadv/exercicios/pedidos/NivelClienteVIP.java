package br.com.fiap.jadv.exercicios.pedidos;

public enum NivelClienteVIP {
	SUPER_IMPORTANTE,
	MUITO_IMPORTANTE,
}
