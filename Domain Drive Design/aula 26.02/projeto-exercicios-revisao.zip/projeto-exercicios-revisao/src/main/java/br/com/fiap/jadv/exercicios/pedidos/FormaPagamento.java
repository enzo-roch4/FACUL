package br.com.fiap.jadv.exercicios.pedidos;

public enum FormaPagamento {
	CARTAO_CREDITO,
	CARTAO_DEBITO,
	DINHEIRO,
	ONLINE
}
