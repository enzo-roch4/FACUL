package br.com.fiap.jadv.exercicios.ex1;

//TODO 01: Encontre o erro da classe acima
public class ClasseComErro {
	private int meuAtributo;
	
	public int getMeuAtributo() {
		return meuAtributo;
	}
	public void setMeuAtributo(int meuAtributo) {
		this.meuAtributo = meuAtributo;
	}
}
