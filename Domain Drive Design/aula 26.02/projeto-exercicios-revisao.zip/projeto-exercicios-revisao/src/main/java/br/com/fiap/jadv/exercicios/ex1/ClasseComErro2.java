package br.com.fiap.jadv.exercicios.ex1;

import java.util.ArrayList;
import java.util.List;

public class ClasseComErro2 {
	private List<Integer> minhaLista = new ArrayList<>();
	
	public List<Integer> getMinhaLista() {
		return minhaLista;
	}
}
