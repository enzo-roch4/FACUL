package br.com.fiap.jadv.exercicios.pedidos;

public class FormaDePagamentoNaoInformadaException extends Exception {
	
	private static final long serialVersionUID = 1L;

	public FormaDePagamentoNaoInformadaException(String mensagem) {
		super(mensagem);
	}
	
	public FormaDePagamentoNaoInformadaException(String mensagem, Throwable t) {
		super(mensagem, t);
	}

}
