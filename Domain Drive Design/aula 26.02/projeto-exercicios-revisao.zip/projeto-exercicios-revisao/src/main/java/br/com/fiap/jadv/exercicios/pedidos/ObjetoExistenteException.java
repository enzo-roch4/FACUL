package br.com.fiap.jadv.exercicios.pedidos;

public class ObjetoExistenteException extends Exception{
	
	public ObjetoExistenteException(String mensagem) {
		super(mensagem);
	}
	
	public ObjetoExistenteException(String mensagem, Throwable t) {
		super(mensagem, t);
	}

}
