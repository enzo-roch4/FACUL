package br.com.fiap.jadv.exercicios.pedidos;

import java.time.LocalDateTime;
import java.util.Objects;

public class Pedido {
	private static int ID_ATUAL = 0;
	
	private int id;
	private Cliente cliente;
	private LocalDateTime data;
	private FormaPagamento formaPagamento;
	private boolean finalizado;
	
	public Pedido(Cliente cliente) {
		
		if (cliente == null) {
			throw new IllegalArgumentException("Cliente inválido");
		}
		
		this.cliente = cliente;
		this.data = LocalDateTime.now();
		ID_ATUAL++;
		this.id = ID_ATUAL;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Cliente getCliente() {
		return cliente;
	}
	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
	public LocalDateTime getData() {
		return data;
	}
	public void setData(LocalDateTime data) {
		this.data = data;
	}
	
	public FormaPagamento getFormaPagamento() {
		return formaPagamento;
	}
	
	public void setFormaPagamento(FormaPagamento formaPagamento) {
		this.formaPagamento = formaPagamento;
	}
	
	public boolean isFinalizado() {
		return finalizado;
	}
	
	public void finalizar() throws FormaDePagamentoNaoInformadaException {
		
		if (this.formaPagamento == null) {
			throw new FormaDePagamentoNaoInformadaException(
					"Forma de pagamento não informada");
		}
		
		this.finalizado = true;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Pedido other = (Pedido) obj;
		return id == other.id;
	}
	
	
}
