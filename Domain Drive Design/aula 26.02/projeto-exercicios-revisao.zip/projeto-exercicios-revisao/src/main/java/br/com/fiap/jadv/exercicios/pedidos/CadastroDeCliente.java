package br.com.fiap.jadv.exercicios.pedidos;

public class CadastroDeCliente extends Cadastro<Cliente>{

}
