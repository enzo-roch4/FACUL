package br.com.fiap.jadv.exercicios.pedidos;

import java.util.ArrayList;
import java.util.List;

public abstract class Cadastro<T> {
	private List<T> cadastrados = new ArrayList<>();
	
	public T buscar (T buscado) {
		for (T existente : cadastrados) {
			if(existente.equals(buscado)) {
				return existente;
			} 
		}
		return null;
	}
	public void inserir(T novoObjeto) throws ObjetoExistenteException {
		if(buscar(novoObjeto) != null) {
			throw new ObjetoExistenteException("Objeto já existente no cadastro");
		} 
		this.cadastrados.add(novoObjeto);
		}
	}
	
