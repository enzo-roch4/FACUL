package br.com.fiap.jadv.exercicios.pedidos;

public class CadastroDePedidos extends Cadastro<Pedido>{
}
