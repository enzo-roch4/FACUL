package br.com.fiap.jadv.exercicios.pedidos;

public class TestePedidos {
     static void tentarFinalizar(Pedido pedido) {
        try{
            pedido.finalizar();
            System.out.println("Pedido " + pedido.getId() + " finalizado");
        }catch(FormaDePagamentoNaoInformadaException ex){
            System.out.println(ex.getMessage());
        }
    }

    public static void main(String[] args) {
        ClienteVIP daniel = new ClienteVIP("Daniel", "daniel@fiap", "123456");
        Pedido pedido1 = new Pedido(daniel);
        tentarFinalizar(pedido1);
        Pedido pedido2 = new Pedido(daniel);
        pedido2.setFormaPagamento(FormaPagamento.CARTAO_DEBITO);
        tentarFinalizar(pedido2);
    }

    }


