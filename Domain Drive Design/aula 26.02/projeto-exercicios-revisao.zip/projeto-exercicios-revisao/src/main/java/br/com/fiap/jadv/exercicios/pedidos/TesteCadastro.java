package br.com.fiap.jadv.exercicios.pedidos;

public class TesteCadastro {
    public static void main(String[] args) throws ObjetoExistenteException {
        CadastroDeCliente cadastro = new CadastroDeCliente();
        Cliente daniel = new Cliente("Daniel", "daniel@fiap", "123456");
        cadastro.inserir(daniel);
        try {
            cadastro.inserir(daniel);
        } catch (ObjetoExistenteException ex){
            System.out.println(ex.getMessage());
        }
        System.out.println("Final do meu programa");
    }
}
