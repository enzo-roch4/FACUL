package br.com.fiap.jadv.exercicios.ex1;

//TODO 03: Corrija o erro de compila��o da classe
public class ClasseComErro3 {

	private MinhaClasse objetoMinhaClasse = new MinhaClasse();
}

class MinhaClasse {
	
}
